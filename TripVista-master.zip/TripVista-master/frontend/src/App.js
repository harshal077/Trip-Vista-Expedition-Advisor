import React, { useState } from "react";
import './App.css';
import RoutesNav from "./RoutesNav";

function App() {

  return (
    <RoutesNav/>
  );
}

export default App;
